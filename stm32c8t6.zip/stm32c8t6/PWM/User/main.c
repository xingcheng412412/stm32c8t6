#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "LED.h"
#include "Key.h"
#include "PWM.h"
#include "Timer.h"
uint8_t Keynum;
uint8_t i;
int main()
{
	Key_Init();
	PWM_Init();
	
	while(1)
	{	
		Keynum = Key_GetNUM();
		if (Keynum == 1)
		{
			for(i = 0; i <= 100; i++)
			{
				PWM_SetCompare1(i);
				Delay_ms(10);
			}
	  }
		if (Keynum == 2)
		{
			for(i = 0; i <= 100; i++)
			{
				PWM_SetCompare1(100 - i);
				Delay_ms(10);
			}
	  }
	}
}


