#ifndef __ULRASONIC_H
#define __ULRASONIC_H

#include "stm32f10x.h"                  // Device header

#define ULRASONIC_GPIO_CLK                       RCC_APB2Periph_GPIOA
#define ULRASONIC_GPIO_PORT                      GPIOA
#define ULRASONIC_TRIG_GPIO_PIN                  GPIO_Pin_0
#define ULRASONIC_ECHO_GPIO_PIN                  GPIO_Pin_1

#define TRIG_Send       PAout(0)
#define ECHO_Reci       PAin(1)


void Ultrasonic_Init(void);
float UltrasonicGetLength(void);
void OpenTimerForHc(void);
void CloseTimerForHc(void);
uint32_t GetEchoTimer(void);

#endif
