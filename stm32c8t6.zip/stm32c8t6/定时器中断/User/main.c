#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "LED.h"
#include "Key.h"
#include "PWM.h"
#include "Timer.h"

int main()
{
	Timer_Init();
	LED_Init();
	
	while(1)
	{	
		
	}
}


