#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "LED.h"
#include "Key.h"
#include "PWM.h"
#include "Timer.h"
#include "Serial.h"

int main()
{
	Key_Init();
	PWM_Init();
	Serial_Init();
	uint8_t Array[2] = {49,50};
	Serial_SendArray(Array, 2);
	while(1)
	{	
		
	}
}


