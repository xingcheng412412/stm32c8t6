#ifndef __COUNT__SENSOR_H
#define __COUNT__SENSOR_H
#include "stm32f10x.h"  
void CountSensor_Init(void);
uint16_t CountSensor_Get(void);
#endif
