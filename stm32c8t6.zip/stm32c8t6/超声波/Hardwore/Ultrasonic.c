#include "stm32f10x.h"                  // Device header
#include "Timer.h"
#include "Delay.h"
#include "OLED.h"
uint16_t msHcCount;

void Ultrasonic_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	Timer_Init();
}

static void OpenTimetForHc()
{
	TIM_SetCounter(TIM4,0);
	msHcCount = 0;
	TIM_Cmd(TIM4,ENABLE);
}

static void CloseTimetForHc()
{
	TIM_Cmd(TIM4,DISABLE);
}

//
uint32_t GetEchoTimer(void)
{
	uint32_t t = 0;
	t = msHcCount*1000;
	t += TIM_GetCounter(TIM4);
	TIM4->CNT = 0;
	Delay_ms(50);
	return t;
}

float UltrasonicGetLength(void)
{
	uint32_t t = 0;
	int i = 0;
	float lengthTemp = 0;
	float sum = 0;
	while(i!=5)
	{
		GPIO_SetBits(GPIOA, GPIO_Pin_0);
		Delay_us(20);
		GPIO_ResetBits(GPIOA, GPIO_Pin_0);
		OLED_ShowNum(1,1,7,2);
		while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1) == 0);
		OpenTimetForHc();
		i = i+1;
		while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1) == 1);
		CloseTimetForHc();
		t = GetEchoTimer();
		lengthTemp = ((float)t/58.0);//cm
		sum = lengthTemp + sum;
	}
	lengthTemp = sum/5.0;
	return lengthTemp;
}







